<p align="center"><img src="https://raw.githubusercontent.com/z1g-project/BruhProx/main/static/uv.png" height="200">
</p>

# Chrome-BruhProx-App
The BruhProx Application for Google Chrome (Works on chromebooks and doesnt show in search history)

# Instructions
 - Open the extentions page (Can be located at: chrome://extentions)
 - Click Developer Mode then select Load Unpacked
 - Select the "BruhProx-5.crx" or the zip file where you obtained it *Note make sure you got it from a secure source and not a sketchy one
 - Once it says Package Loaded you have sucessfully installed the BruhProx Application
 
 # Image
 [Screenshot 2023-01-12 10 38 26 AM](https://user-images.githubusercontent.com/72810050/212111489-b6d411d9-1d9a-46b6-acf5-38cdf6a1e239.png)
![image](https://user-images.githubusercontent.com/72810050/212111601-4df082cd-f144-4b64-9b69-ebf5222706a9.png)

# Credits
 - Art & Design - Blurred#0527
 - Source & Development - XSTARS#9715!
