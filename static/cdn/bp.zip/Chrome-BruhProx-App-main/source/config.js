window.config = {
   "model_": "AppConfig",
   "id": 1,
   "appName": "BruhProx",
   "version": "6.0.0",
   "homepage": "https://bruhprox.glitch.me/",
   "enableLogoutBttn": false,
   "termsOfService": "",
   "kioskEnabled": true
};
